<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "belas";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verifique a conexão
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Consulta os dados do banco de dados
$sql = "SELECT nome, email, comentario FROM `feedback`";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Saída dos dados em uma tabela HTML
    echo "<h3>Feedbacks recebidos:</h3>";
    echo "<table>";
    echo "<tr><th>Nome</th><th>Email</th><th>Comentário</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["nome"] . "</td><td>" . $row["email"] . "</td><td>" . $row["comentario"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p>Nenhum feedback recebido ainda.</p>";
}

// Feche a conexão com o banco de dados
$conn->close();
?>


