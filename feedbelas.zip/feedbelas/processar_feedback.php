<?php
// Dados de conexão ao banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "belas";

// Conectando ao banco de dados
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Obtendo os dados do formulário
$nome = $_POST['nome'];
$email = $_POST['email'];
$comentario = $_POST['comentario'];

// Inserir os dados na tabela do banco de dados usando consulta preparada
$stmt = $conn->prepare("INSERT INTO feedback (nome, email, comentario) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $nome, $email, $comentario);

if ($stmt->execute()) {
    // Redirecionar para feedback.html com a mensagem de sucesso na URL
    header("Location: feedback.html?status=Feedback enviado com sucesso!");
    exit();
} else {
    echo "Erro ao enviar o feedback: " . $stmt->error;
}

// Fechar a conexão com o banco de dados
$stmt->close();
$conn->close();
?>
